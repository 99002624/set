//#include<algorithm>
#include "Fraction.h"
#include<iostream>
namespace using std;

Fraction::Fraction():m_numerator(0),m_denominator(0){};

Fraction::Fraction(int x,int y):m_numerator(x),m_denominator(y){};

Fraction::Fraction(int x):m_numerator(x),m_denominator(x){};

Fraction Fraction::operator+(const Fraction & ref){

        int num=m_numerator+ref.m_numerator;
        int den=m_denominator+ref.m_denominator;
        return Fraction(num,den);

}
Fraction Fraction::operator-(const Fraction & ref){

        int num=m_numerator-ref.m_numerator;
        int den=m_denominator-ref.m_denominator;
        return Fraction(num,den);

}

Fraction Fraction::operator*(const Fraction & ref){

        int num=m_numerator*ref.m_numerator;
        int den=m_denominator*ref.m_denominator;
        return Fraction(num,den);

}
Fraction Fraction::operator+(int x){

        int num=m_numerator+x;
        int den=m_denominator+x;
        return Fraction(num,den);

}

Fraction Fraction::operator-(int x){

        int num=m_numerator-x;
        int den=m_denominator-x;
        return Fraction(num,den);

}
bool Fraction::operator==(const Fraction & ref){

        return m_numerator==ref.m_numerator && m_denominator==ref.m_denominator;
}

bool Fraction::operator<(const Fraction & ref){

        if(m_numerator<=ref.m_numerator && m_denominator>ref.m_denominator )
                return true;
        return false;
}

bool Fraction::operator>(const Fraction & ref){

        if(m_numerator>=ref.m_numerator && m_denominator<ref.m_denominator )
                return true;
        return false;
}

void Fraction ::display(){

        std::cout<<m_numerator<<"/"<<m_denominator;
}












