#include<iostream>
#include "time.h"
#include <gtest/gtest.h>

TEST(MyTime,constructor){

        MyTime c1(12,25,30);
        MyTime c2(1,15,10);
        MyTime c3;
        c3=c1+c2;
        std::string ExpectedOut="13:40:40";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(MyTime,minus1){

        MyTime c1(12,25,30);
        MyTime c2(1,15,10);
        MyTime c3;
        c3=c1-c2;
        std::string ExpectedOut="11:10:20";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(MyTime,operatorplusplus){

        MyTime c1(12,25,30);
        //MyTime c2(1,15,10);
        MyTime c3;
        c3=c1++;
        std::string ExpectedOut="12:25:30";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}
TEST(MyTime,plusplusoperator){

        MyTime c1(12,25,30);
        ///MyTime c2(1,15,10);
        MyTime c3;
        c3=++c1;
        std::string ExpectedOut="13:25:30";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}



