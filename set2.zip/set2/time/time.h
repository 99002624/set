//#ifndef DISTANCE_H_INCLUDED
//#define DISTANCE_H_INCLUDED
class MyTime {
    int m_hours;
    int m_minutes;
    int m_seconds;
  public:
    // Constructers

    MyTime();
    MyTime(int,int,int);
    MyTime(int,int );

    // members
    MyTime operator+(const MyTime &ref);

    MyTime operator-(const MyTime &ref);
    MyTime operator*(const MyTime &ref);
    MyTime operator+(int);
    MyTime operator-(int);

    MyTime& operator++();
   MyTime operator++(int dummy);
    bool operator< (const MyTime &ref);
    bool operator> (const MyTime &ref);


    bool operator==(const MyTime &ref);

    void display();



};


//#endif // DISTANCE_H_INCLUDED


