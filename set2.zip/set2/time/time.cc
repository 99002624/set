#include "time.h"
#include <iostream>


MyTime::MyTime():m_hours(0),m_seconds(0),m_minutes(0){};

MyTime::MyTime(int x,int y,int z):m_hours(x),m_minutes(y),m_seconds(z){};

MyTime::MyTime(int x,int z):m_hours(x),m_minutes(z),m_seconds(0){};


MyTime MyTime::operator+(const MyTime &ref ){

            int hour = m_hours+ref.m_hours;
            int minute=m_minutes+ref.m_minutes;
            int seconds=m_seconds+ref.m_seconds;
            return MyTime(hour,minute,seconds);

}



MyTime MyTime::operator-(const MyTime &ref ){

            int hour = m_hours-ref.m_hours;
            int minute=m_minutes-ref.m_minutes;
            int seconds=m_seconds-ref.m_seconds;
            return MyTime(hour,minute,seconds);

}
MyTime MyTime::operator+(int x){

          int hour = m_hours+x;
            int minute=m_minutes+x;
            int seconds=m_seconds+x;
            return MyTime(hour,minute,seconds);

}

MyTime MyTime::operator-(int x){

           int hour = m_hours-x;
            int minute=m_minutes-x;
            int seconds=m_seconds-x;
            return MyTime(hour,minute,seconds);

}

MyTime& MyTime::operator++(){

           MyTime c;
           c.m_hours=++m_hours;
           c.m_minutes=++m_minutes;
           c.m_seconds=++m_seconds;
           return c;
}
MyTime MyTime::operator++(int dummy ){

           MyTime temp(*this);
           ++m_seconds;
           return temp;

}

bool MyTime::operator==(const MyTime & ref){

    return m_hours==ref.m_hours && m_minutes==ref.m_minutes && m_seconds==ref.m_seconds;

}


bool MyTime::operator<(const MyTime & ref){

        if(m_hours<ref.m_hours)
                return true;

        if(m_hours==ref.m_hours && m_minutes<ref.m_minutes)
                 return true;
         if(m_hours==ref.m_hours && m_minutes==ref.m_minutes && m_seconds<m_seconds)
                 return true;
        return false;

}

bool MyTime::operator>(const MyTime & ref){
        if(m_hours>ref.m_hours)
                return true;

        if(m_hours==ref.m_hours && m_minutes>ref.m_minutes)
                 return true;
         if(m_hours==ref.m_hours && m_minutes==ref.m_minutes && m_seconds>m_seconds)
                 return true;
        return false;

}

void MyTime::display(){

        std::cout<<m_hours<<":"<<m_minutes<<":"<<m_seconds;

}
