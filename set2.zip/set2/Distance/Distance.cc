#include "Distance.h"

#include<iostream>

Distance::Distance():m_feets(0),m_inches(0){}

Distance::Distance(int x, int y):m_feets(x),m_inches(y){}

Distance Distance::operator+(const Distance &ref ){

            int feet = m_feets+ref.m_feets;
            int inches=m_inches+ref.m_inches;
            return Distance(feet,inches);

}



Distance   Distance::operator-(const Distance & ref){

           int feet = m_feets-ref.m_feets;
            int inches=m_inches-ref.m_inches;
            return Distance(feet,inches);

}
Distance Distance::operator+(int x){

           int feet = m_feets+x;
            int inches=m_inches+x;
            return Distance(m_feets,m_inches);

}

Distance Distance::operator-(int x){

           int feet = m_feets-x;
            int inches=m_inches-x;
            return Distance(m_feets,m_inches);

}

Distance& Distance::operator++(){

           ++m_inches;
            return *this;

}
Distance Distance::operator++(int dummy ){

           Distance temp(*this);
           ++m_feets;
           return temp;

}

bool Distance::operator==(const Distance & ref){

    return m_feets==ref.m_feets && m_inches==ref.m_inches;

}


bool Distance::operator<(const Distance & ref){

        if(m_feets<ref.m_feets)
                return true;

        if(m_feets==ref.m_feets && m_inches<ref.m_inches)
                 return true;
        return false;

}

bool Distance::operator>(const Distance & ref){

        if(m_feets>ref.m_feets)
                return true;

        if(m_feets==ref.m_feets && m_inches>ref.m_inches)
                 return true;
        return false;

}

void Distance::display(){

        std::cout<<m_feets<<"."<<m_inches;

}
