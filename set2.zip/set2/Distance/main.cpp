#include<iostream>
#include "Distance.h"
#include <gtest/gtest.h>

TEST(Distance,constructor){

        Distance c1(25,1);
        Distance c2(50,15);
        Distance c3;
        c3=c1+c2;
        std::string ExpectedOut="75.16";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(Distance,minus){

        Distance c1(25,15);
        Distance c2(50,15);
       Distance c3;
        c3=c1-c2;
        std::string ExpectedOut="-25.0";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(Distance,operaplusplus){

        Distance c1(25,15);
        //Currency c2(50,15);
       Distance c3;
        c3=c1++;
        std::string ExpectedOut="25.15";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}
TEST(CDistance,plusplusopera){

        Distance c1(25,15);
        //Currency c2(50,15);
        Distance c3;
        c3=++c1;
        std::string ExpectedOut="25.16";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}


