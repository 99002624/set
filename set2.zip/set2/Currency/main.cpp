#include<iostream>
#include "Currency.h"
#include <gtest/gtest.h>

TEST(Currency,constructor){

        Currency c1(25,101);
        Currency c2(50,15);
        Currency c3;
        c3=c1+c2;
        std::string ExpectedOut="76.17";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(Currency,minus){

        Currency c1(25,15);
        Currency c2(50,15);
        Currency c3;
        c3=c1-c2;
        std::string ExpectedOut="-25.0";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}

TEST(Currency,operaplusplus){

        Currency c1(25,15);
        //Currency c2(50,15);
        Currency c3;
        c3=c1++;
        std::string ExpectedOut="25.15";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());

}
TEST(Currency,plusplusopera){

        Currency c1(25,15);
        //Currency c2(50,15);
        Currency c3;
        c3=++c1;
        bool k=c1<c3;
        ASSERT_EQ(false,k);
        /*Astd::string ExpectedOut="25.16";
        testing::internal::CaptureStdout();
        c3.display();
        std::string ActualOut = testing::internal::GetCapturedStdout();
        EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());*/

}

