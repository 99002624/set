#include "Currency.h"
#include<iostream>

Currency::Currency():m_rupees(0),m_paise(0){};

Currency::Currency(int x,int y):m_rupees(x),m_paise(y){};

Currency::Currency(int x):m_rupees(x),m_paise(x){};

Currency  Currency::operator+(const Currency & ref){

            int rupees = m_rupees+ref.m_rupees;
            int paise  = m_paise+ref.m_paise;
            while(paise>99){

                paise=paise-99;
                rupees +=1;

            }
            return Currency(rupees,paise);

}

Currency Currency::operator-(const Currency & ref){

            int rupees = m_rupees-ref.m_rupees;
            if(m_paise==0&&ref.m_paise>0){

                    m_paise=100;
                    m_rupees-=1;


            }
            int paise  = m_paise-ref.m_paise;
            return Currency(rupees,paise);

}
Currency& Currency::operator++(){

            ++m_paise;
            return *this;
}

Currency Currency::operator++(int ){
            Currency temp(*this);
            ++m_paise;
            return temp;
}

bool Currency::operator==(const Currency & ref){

           return  m_rupees==ref.m_rupees && m_paise == ref.m_paise;

}

bool Currency::operator<(const Currency & ref){

          return  m_rupees<ref.m_rupees;


}
bool Currency::operator>(const Currency & ref){

          // return Currency m_rupees<ref.m_rupees;


}

void Currency::display(){

            std::cout<<m_rupees<<"."<<m_paise;
}

