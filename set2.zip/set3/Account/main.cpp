//#include "pch.h"
#include "CreditAccount.h"
#include "SavingsAccount.h"
#include "Account.h"
#include<gtest/gtest.h>

#include<iostream>
#include<math.h>
TEST(TestCase, Test) {

    CreditAccount s1("1","2",3);
    s1.credit(10);
    EXPECT_EQ(13,s1.getBalance());
    EXPECT_TRUE(true);
}

TEST(TestCase, Test1) {

    SavingsAccount s1("1","2",3);
    s1.credit(10);
     s1.debit(10);
    EXPECT_EQ(3,s1.getBalance());
    EXPECT_TRUE(true);
}
/*int main()
{   AccountBase *b;
    CreditAccount c1;
    b=&c1;
    b->credit(10);

}*/

