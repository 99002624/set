



class Box {

    int m_lenght;
    int m_height;
    int m_breadth;
    int m_volume;


  public :



    Box();

    Box(int lenght,int breadth, int height);

    Box(const Box & ref);


    void Volume();
    int getVolume();


    void display();



};

