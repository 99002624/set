#include <iostream>
#include "box.h"
#include <gtest/gtest.h>


TEST(Box,DefaultConstructor){

    Box b;
    EXPECT_EQ(0,b.getVolume());

}

TEST(Box,parameterConstructor){

    Box b1(1,2,3);
    b1.Volume();
    EXPECT_EQ(6,b1.getVolume());

}




TEST(Box,Constructor){

    Box b5(10,2,3);
    Box b6(b5);
    b6.Volume();
    EXPECT_EQ(60,b6.getVolume());

}


