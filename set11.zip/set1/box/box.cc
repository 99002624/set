#include<iostream>
#include "box.h"
using namespace std;

Box::Box() :m_lenght(0),m_height(0),m_breadth(0) {}

Box::Box(int lenght,int breadth,int height):m_lenght(lenght),m_height(breadth),m_breadth(height) {

}
Box::Box(const Box &ref ):m_lenght(ref.m_lenght),m_height(ref.m_breadth),m_breadth(ref.m_height) {
}


void Box :: Volume() {
         m_volume =  m_lenght*m_breadth*m_height;
    //return volume;
}
int Box :: getVolume(){
    return m_volume;

}
void Box:: display() {
        std::cout<<m_volume<<endl;
}

