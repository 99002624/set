#include "all.h"
#include<iostream>



Image::
