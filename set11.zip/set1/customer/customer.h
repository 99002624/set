enum AccountType{
        savings,current
};


class Customer{

        int m_custID,m_phone,m_custName;
        double m_balance;
    public:
        Customer();
        Customer(AccountType);
        Customer(int,int,int,double);
        //Customer(AccountType);
        Customer(int,int,int);
        Customer(const Customer &);
        void Credit(double);
        double getBlance();
        void Display();



};
