class Point{

            int  m_x,m_y;
        public :
            Point();
            Point(int,int);
            Point(const Point & );
            void distanceFromOrigin();
            void isOrigin();
            void isOnYAxis();
            void isONXAxis();
            void display();
            void Quadrant();
};
