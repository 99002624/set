#include "kiran.h"

#include <gtest/gtest.h>

TEST(Image,DefaultConstuctor){

        Image a;
        a.move(1,1);

        std::string ExpectedOut="1,1";
    testing::internal::CaptureStdout();
    a.display();
    std::string ActualOut = testing::internal::GetCapturedStdout();
    EXPECT_STREQ(ExpectedOut.c_str(), ActualOut.c_str());


}

/*TEST(Image,paraConstuctor){

        Image a1(10,20,40,50);

        //a.move(1,1);
        EXPECT_EQ(20,a1.resize(10,20));
        // EXPECT_EQ(2040,a1.display());

}*/
