#include<string>

class Account
{
        int m_accNumber;
       std:: string m_accName;
        double m_balance;
    public:
            int balance;
            Account();
            Account(int number, std::string name, double balance);
            Account(const Account &);
            double getBalance();
            void credit(double amount );
            void debit(double amount1);
            void display();

};
