#include "account.h"
#include <gtest/gtest.h>


TEST(Account,DefaultCoustor){

    Account a;
    a.credit(200);
    EXPECT_EQ(200,a.getBalance());

}

TEST(Account,Coustor){

    Account a(123,"kiran",50000);
    a.credit(200);
    a.debit(300);
    EXPECT_EQ(49900,a.getBalance());

}




TEST(Account,copyCoustor){

    Account a(123,"kiran",50000);
     Account a1(a);
    a1.credit(200);
    a1.debit(300);
    EXPECT_EQ(49900,a1.getBalance());

}
