
#include "account.h"
#include<iostream>

using namespace std;

Account::Account():m_accNumber(0),m_accName(""),m_balance(0){}


Account::Account(int number, string name, double balance):m_accNumber(number),m_accName(name),m_balance(balance){


}
Account::Account(const Account & ref):m_accNumber(ref.m_accNumber),m_accName(ref.m_accName),m_balance(ref.m_balance){

}
double Account::getBalance(){

            return m_balance;
}

void Account::debit(double amount){
        m_balance -=amount;

}

void Account::credit(double amount1){
        m_balance +=amount1;

}

void Account::display(){
        cout<<m_balance<<endl;

}
