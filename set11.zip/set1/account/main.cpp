#include <iostream>
#include "account.h"


int main() {

    Account a1(123,"kiran",999);
    a1.display();
    a1.credit(444);
    a1.display();
    a1.debit(222);
     a1.display();
    return 0;

}
